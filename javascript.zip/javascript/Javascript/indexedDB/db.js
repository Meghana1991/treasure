/**
 * We open version 1 of a database named myDatabase, but indexedDB.open doesn’t return a database, it returns a request for a database because IndexedDB is an asynchronous API.
 */
let db;
let dbReq = indexedDB.open('myDatabase', 1);

/**
 * myDatabase didn’t previously exist, so it’s automatically created and then the onupgradeneeded event fires. In an onupgradeneeded callback, and only in that callback, we can create a database’s object stores. So first, with db = event.target.result, we set the variable db to hold our database. Then, we create one object store named notes.
 */
dbReq.onupgradeneeded = function (event) {
    // Set the db variable to our database so we can use it!  
    db = event.target.result;

    // Create an object store named notes. Object stores
    // in databases are where data are stored.
    let notes = db.createObjectStore('notes', { autoIncrement: true });
}
/**
 * onsuccess fires after onupgradeneeded completes and it also fires if we refresh the page and open the database again. So there too, we run db = event.target.result to get our database so we can use it.
 */
dbReq.onsuccess = function (event) {
    db = event.target.result;
    // Add some sticky notes
    addStickyNote(db, 'Sloths are awesome!');
    addStickyNote(db, 'Order more hibiscus tea');
}
dbReq.onerror = function (event) {
    alert('error opening database ' + event.target.errorCode);
}

function submitNote() {
    let message = document.getElementById('newmessage');
    this.addStickyNote(db, message.value);
    message.value = '';
}

function addStickyNote(db, message) {
    // Start a database transaction and get the notes object store
    let tx = db.transaction(['notes'], 'readwrite');
    let store = tx.objectStore('notes');
    // Put the sticky note into the object store
    let note = { text: message, timestamp: Date.now() };
    store.add(note);
    // Wait for the database transaction to complete
    tx.oncomplete = function () { console.log('stored note!') }
    tx.onerror = function (event) {
        alert('error storing note ' + event.target.errorCode);
    }
}