let str = "We will, we will rock you";
console.log(str.match(/we/gi)); // We,we (an array of 2 substrings that match)

let str = "We will, we will rock you";
let result = str.match(/we/i); // without flag g

console.log(result[0]);     // We (1st match)
console.log(result.length); // 1

// no flag g
console.log("We will, we will".replace(/we/i, "I")); // I will, we will

// with flag g
console.log("We will, we will".replace(/we/ig, "I")); // I will, I will

let str = "+7(903)-123-45-67";

let regexp = /\d/;

console.log(str.match(regexp)); // 7

/**
 * \d (“d” is from “digit”)
A digit: a character from 0 to 9.
\s (“s” is from “space”)
A space symbol: includes spaces, tabs \t, newlines \n and few other rare characters, such as \v, \f and \r.
\w (“w” is from “word”)
A “wordly” character: either a letter of Latin alphabet or a digit or an underscore _. Non-Latin letters (like cyrillic or hindi) do not belong to \w.
For instance, \d\s\w means a “digit” followed by a “space character” followed by a “wordly character”, such as 1 a.
 */

let str = "Is there CSS4?";
let regexp = /CSS\d/

console.log(str.match(regexp)); // CSS4
//-----------------------------------------------------------------
/**
 * Inverse classes
For every character class there exists an “inverse class”, denoted with the same letter, but uppercased.

The “inverse” means that it matches all other characters, for instance:
\D
Non-digit: any character except \d, for instance a letter.
\S
Non-space: any character except \s, for instance a letter.
\W
Non-wordly character: anything but \w, e.g a non-latin letter or a space.
 */

let goodInput = "12:34";
let badInput = "12:345";

let regexp = /^\d\d:\d\d$/;
console.log(regexp.test(goodInput)); // true
console.log(regexp.test(badInput)); // false

//The multiline mode is enabled by the flag m.
let str = `1st place: Winnie
2nd place: Piglet
3rd place: Eeyore`;

console.log(str.match(/^\d/gm)); // 1, 2, 3

console.log("Exception 0xAF".match(/x[0-9A-F][0-9A-F]/g)); // xAF
console.log("alice15@gmail.com".match(/[^\d\sA-Z]/gi)); // @ and .
console.log("I'm 12345 years old".match(/\d{5}/)); //  "12345"
console.log("I'm not 12, but 1234 years old".match(/\d{3,5}/)); // "1234"
console.log("I'm not 12, but 345678 years old".match(/\d{3,}/)); // "345678"

let str = "+7(903)-123-45-67";
let numbers = str.match(/\d{1,}/g);
console.log(numbers); // 7,903,123,45,67

let str = "Should I write color or colour?"; //For instance, the pattern ou?r looks for o followed by zero or one u, and then r.
console.log(str.match(/colou?r/g)); // color, colour

//\d0* looks for a digit followed by any number of zeroes (may be many or none):
console.log("100 10 1".match(/\d0*/g)); // 100, 10, 1

console.log("100 10 1".match(/\d0+/g)); // 100, 10
// 1 not matched, as 0+ requires at least one zero

console.log("0 1 12.345 7890".match(/\d+\.\d+/g)); // 12.345
console.log("<body> ... </body>".match(/<[a-z]+>/gi)); // <body>
console.log("<h1>Hi!</h1>".match(/<[a-z][a-z0-9]*>/gi)); // <h1>
console.log("<h1>Hi!</h1>".match(/<\/?[a-z][a-z0-9]*>/gi)); // <h1>, </h1>
//-----------------------------------------------------------------
console.log('Gogogo now!'.match(/(go)+/i)); // "Gogogo"
let regexp = /(\w+\.)+\w+/g;
console.log("site.com my.site.com".match(regexp)); // site.com,my.site.com

//A dot . inside square brackets means just a dot. The pattern [.,] would look for one of characters: either a dot or a comma.

//In the example below the regexp [-().^+] looks for one of the characters -().^+:

/**
 * We already saw a similar thing – square brackets. They allow to choose between multiple characters, for instance gr[ae]y matches gray or grey.

Square brackets allow only characters or character sets. Alternation allows any expressions. A regexp A|B|C means one of expressions A, B or C.
For instance:

gr(a|e)y means exactly the same as gr[ae]y.
gra|ey means gra or ey.

To apply alternation to a chosen part of the pattern, we can enclose it in parentheses:
I love HTML|CSS matches I love HTML or CSS.
I love (HTML|CSS) matches I love HTML or I love CSS.
 */

//-----------------------------------------------------------------
/**Lookahead
The syntax is: X(?=Y), it means "look for X, but match only if followed by Y". There may be any pattern instead of X and Y.

For an integer number followed by €, the regexp will be \d+(?=€):
 */
let str = "1 turkey costs 30€";

alert(str.match(/\d+(?=€)/)); // 30, the number 1 is ignored, as it's not followed by €
//-----------------------------------------------------------------
